
  # Rural Entrepreneur Information App (Copy)

  This is a code bundle for Rural Entrepreneur Information App (Copy). The original project is available at https://www.figma.com/design/zz4kJ4CimDVEtIfrBiZZ80/Rural-Entrepreneur-Information-App--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  